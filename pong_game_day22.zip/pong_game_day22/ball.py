from turtle import Turtle
import random
a = round(random.uniform(3.75 , 4.5),2)
print(a)

class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("white")
        self.penup()
        self.xchange = 4
        self.ychange = 3
        self.move_speed = 0.01
    def move(self):

        new_x = self.xcor()+self.xchange
        new_y = self.ycor() + self.ychange
        self.goto(new_x,new_y)

    def reflect(self):
        self.ychange *= -1

    def reflect_at_bar(self):
        self.xchange *= -1
        self.move_speed*=0.9