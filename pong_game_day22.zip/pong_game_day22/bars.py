from turtle import Turtle
positions_right = [(570 ,-20),(570,0),(570,20)]
positions_left = [(-570,-20),(-570,0),(-570,20) ]


class Bars():

    def __init__(self):

        self.segments = []

        self.create_bars()

    def create_bars(self):
        for position in positions_right:
            self.add_segment(position)
        for position in positions_left:
            self.add_segment(position)

    def add_segment(self,position):
        segment = Turtle("square")

        segment.color("white")
        segment.penup()
        segment.goto(position)
        segment.setheading(90)
        self.segments.append(segment)

    def right_up(self):
        for i in range(0,3):
            self.segments[i].forward(20)

    def left_up(self):
        for i in range(0, 3):
            self.segments[i+3].forward(20)


    def right_down(self):
        for i in range(0,3):
            self.segments[2-i].backward(20)

    def left_down(self):
        for i in range(0,3):
            self.segments[5-i].backward(20)