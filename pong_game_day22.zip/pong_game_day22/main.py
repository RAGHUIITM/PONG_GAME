import time
from turtle import Turtle , Screen
from bars import Bars
from score import Leftscoreboard , Rightscoreboard
from ball import Ball

turtle=Turtle()
ball = Ball()
screen = Screen()
screen.tracer(0)
screen.setup(width = 1200 , height = 700)
screen.bgcolor("black")
left = Leftscoreboard()
right = Rightscoreboard()

for i in range (0,10) :
    titu = Turtle()
    titu.shape("square")
    titu.color("white")
    titu.shapesize(stretch_len=0.5 , stretch_wid= 1.5)
    titu.penup()
    titu.goto(0,-330+(70*i))



bars = Bars()
screen.listen()
screen.onkeypress(bars.right_up, "Up")
screen.onkeypress(bars.left_up, "w")
screen.onkeypress(bars.right_down, "Down")
screen.onkeypress(bars.left_down, "s")

game_is_on = True
while game_is_on :
    screen.update()
    time.sleep(ball.move_speed)
    ball.move()
    if ball.ycor() < -330 or ball.ycor() > 330 :
        ball.reflect()
    if ( ball.xcor() == 560 or ball.xcor() == -560) and (( bars.segments[1].distance(ball) < 50 or  bars.segments[4].distance(ball) ) < 50) :
        ball.reflect_at_bar()
    if ball.xcor() > 620 :
        left.increment_left()
        time.sleep(1)
        ball.goto(x=0,y=0)
        ball.xchange = 4
        ball.ychange = 3
        ball.move_speed = 0.01
    if ball.xcor() < -620 :
        right.increment_right()
        time.sleep(1)
        ball.goto(x=0, y=0)
        ball.xchange = 4
        ball.ychange = 3
        ball.move_speed = 0.01


screen.exitonclick()
