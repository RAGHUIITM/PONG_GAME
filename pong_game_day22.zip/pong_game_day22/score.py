from turtle import Turtle
from ball import Ball


class Leftscoreboard(Turtle) :
    def __init__(self):
        super().__init__()
        self.penup()
        self.goto(-500 , 300)
        self.color("white")
        self.left_score = 0
        self.hideturtle()

        self.write(f" SCORE : {self.left_score}" ,align ="center" , font = ("Arial",24, "normal"))


    def increment_left(self):
        self.left_score+=1
        self.clear()
        self.write(f" SCORE : {self.left_score}", align="center", font=("Arial", 24, "normal"))


class Rightscoreboard(Turtle):
    def __init__(self):
            super().__init__()
            self.penup()
            self.goto(500, 300)
            self.color("white")
            self.right_score = 0
            self.hideturtle()
            self.write(f" SCORE : {self.right_score}", align="center", font=("Arial", 24, "normal"))

    def increment_right(self):
            self.right_score += 1
            self.clear()
            self.write(f" SCORE : {self.right_score}", align="center", font=("Arial", 24, "normal"))
